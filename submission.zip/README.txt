How to run:
To run the entire assignment and to witness all of the inputs simultaneously, simply uncomment the functions in the main block.
To run one question at a time, uncomment whichever question part you choose to run. All of the functions in the main block are
independent of each other and can be run seperately. A list of these functions is shown below. All of the appropriate figures will 
autogenerate into the results folder. All of the figures have already been generated. 

Functions in main block:
question1a()
question1b()
question1c()